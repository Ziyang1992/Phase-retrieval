# Phase retrieval with background information
Those codes implement the algorithm in Phase retrieval with background information
--------------------------------------------------------------------------------------------------------------------------

  Code demo for "Phase retrieval with background information"
                        

------------------------------------------------------------------------------------------------------------------------------------
 Contents
------------------------------------------------------------------------------------------------------------------------------------
Note: Before running the codes, please change Matlab current folder

------------------------------------------------------------------------------------------------------------------------------------
 Disclaimer
------------------------------------------------------------------------------------------------------------------------------------

Any unauthorized use of these routines for industrial or profit-oriented activities is expressively prohibited.

------------------------------------------------------------------------------------------------------------------------------------
 Feedback
------------------------------------------------------------------------------------------------------------------------------------

If this code offers help in your research, please cite our paper:

"Phase retrieval with background information"

If you have any comment, suggestion, or question, please contact Ziyang Yuan at yuanziyang11@nudt.edu.cn.
